package com.example.reconstruct

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
